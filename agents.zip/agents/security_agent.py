
class SecurityAgent:
    def __init__(self, name='SecurityAgent'):
        self.name = name

    def review_code(self, code):
        issues = []
        if 'eval(' in code:
            issues.append("Potential security issue: 'eval' function detected.")
        return issues

    def fix_code(self, code):
        return code.replace('eval(', 'safe_eval(')
