
class CodeConformanceAgent:
    def __init__(self, name='CodeConformanceAgent'):
        self.name = name

    def review_code(self, code):
        issues = []
        if not code.strip().endswith(';'):
            issues.append("Code style issue: line should end with a semicolon.")
        return issues

    def fix_code(self, code):
        if not code.strip().endswith(';'):
            code = code.strip() + ';'
        return code
